<?php 
    ob_start();
    session_start();

    include("functions/db.php");
    include("functions/function.php");
    

?>